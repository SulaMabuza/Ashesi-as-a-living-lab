#include <jni.h>
#include <string>
#include <algorithm>
#include <iostream>
#pragma comment( lib, "Winmm.lib" )
#include <cstddef>
using namespace std;
extern "C" JNIEXPORT jstring JNICALL
Java_com_example_cleanapp_MainActivity_stringFromJNI(
        JNIEnv *env,
        jobject /* this */) {
    std::string hello = "Keep the environment clean!";
    return env->NewStringUTF(hello.c_str());
}
