package com.example.cleanapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
public class MainActivity extends AppCompatActivity {
    private Button sign_in;
    private Button sign_up;
    private ImageButton scanner;

    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sign_in = (Button) findViewById(R.id.sign_in);
        sign_up = (Button) findViewById(R.id.sign_up);
        scanner = (ImageButton) findViewById(R.id.scanner);

        // Example of a call to a native method
        //TextView tv = findViewById(R.id.sample_text);

        //tv.setText(stringFromJNI());


        sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MyWallet.class);
                startActivity(intent);
            }
        });

       
//        public native String stringFromJNI (); {
//
//        }

    }
}
